app.service('ordinaryService',function($http){

})